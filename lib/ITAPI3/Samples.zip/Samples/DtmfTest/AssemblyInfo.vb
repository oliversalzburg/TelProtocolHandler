Imports System.Reflection
Imports System.Runtime.CompilerServices
Imports System.Runtime.InteropServices

' General Information about an assembly is controlled through the following
' set of attributes. Change these attribute values to modify the information
' associated with an assembly.





<Assembly: AssemblyTitle("Microsoft� Windows(TM) TAPI 3.0 DTMF Generation/Detection Sample")>
<Assembly: AssemblyDescription("")>
<Assembly: AssemblyCompany("Microsoft Corporation")>
<Assembly: AssemblyProduct("")>
<Assembly: AssemblyCopyright("Copyright (C) Microsoft Corp. 1997-1999")>
<Assembly: AssemblyTrademark("")>
<Assembly: AssemblyCulture("")>

' Version information for an assembly consists of the following four values:

'	Major version
'	Minor Version
'	Build Number
'	Revision

' You can specify all the values or you can default the Build and Revision Numbers
' by using the '*' as shown below:

<Assembly:  AssemblyVersion("1.1.*")>


